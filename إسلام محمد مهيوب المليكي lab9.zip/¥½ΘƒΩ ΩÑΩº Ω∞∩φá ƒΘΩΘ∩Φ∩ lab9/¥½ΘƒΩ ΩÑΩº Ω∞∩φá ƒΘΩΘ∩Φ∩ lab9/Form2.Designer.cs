﻿namespace إسلام_محمد_مهيوب_المليكي_lab9
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtId = new System.Windows.Forms.TextBox();
            this.listBoxIds = new System.Windows.Forms.ListBox();
            this.listBoxNames = new System.Windows.Forms.ListBox();
            this.txtName = new System.Windows.Forms.TextBox();
            this.listBoxAges = new System.Windows.Forms.ListBox();
            this.txtAge = new System.Windows.Forms.TextBox();
            this.listBoxGenders = new System.Windows.Forms.ListBox();
            this.radioBtnFeminine = new System.Windows.Forms.RadioButton();
            this.radioBtnMale = new System.Windows.Forms.RadioButton();
            this.btnEdit = new System.Windows.Forms.Button();
            this.btnDeletesAll = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnAdd = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(50, 22);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(59, 19);
            this.label4.TabIndex = 16;
            this.label4.Text = "الجنس";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(204, 22);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(46, 19);
            this.label3.TabIndex = 15;
            this.label3.Text = "العمر";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(365, 22);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(54, 19);
            this.label2.TabIndex = 14;
            this.label2.Text = "الاسم";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(528, 22);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(47, 19);
            this.label1.TabIndex = 13;
            this.label1.Text = "الرقم";
            // 
            // txtId
            // 
            this.txtId.Location = new System.Drawing.Point(486, 66);
            this.txtId.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.txtId.Name = "txtId";
            this.txtId.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.txtId.Size = new System.Drawing.Size(124, 27);
            this.txtId.TabIndex = 17;
            this.txtId.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // listBoxIds
            // 
            this.listBoxIds.FormattingEnabled = true;
            this.listBoxIds.ItemHeight = 19;
            this.listBoxIds.Location = new System.Drawing.Point(486, 108);
            this.listBoxIds.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.listBoxIds.Name = "listBoxIds";
            this.listBoxIds.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.listBoxIds.Size = new System.Drawing.Size(124, 213);
            this.listBoxIds.TabIndex = 18;
            // 
            // listBoxNames
            // 
            this.listBoxNames.FormattingEnabled = true;
            this.listBoxNames.ItemHeight = 19;
            this.listBoxNames.Location = new System.Drawing.Point(309, 108);
            this.listBoxNames.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.listBoxNames.Name = "listBoxNames";
            this.listBoxNames.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.listBoxNames.Size = new System.Drawing.Size(150, 213);
            this.listBoxNames.TabIndex = 20;
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(309, 66);
            this.txtName.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.txtName.Name = "txtName";
            this.txtName.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.txtName.Size = new System.Drawing.Size(150, 27);
            this.txtName.TabIndex = 19;
            this.txtName.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // listBoxAges
            // 
            this.listBoxAges.FormattingEnabled = true;
            this.listBoxAges.ItemHeight = 19;
            this.listBoxAges.Location = new System.Drawing.Point(158, 108);
            this.listBoxAges.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.listBoxAges.Name = "listBoxAges";
            this.listBoxAges.Size = new System.Drawing.Size(124, 213);
            this.listBoxAges.TabIndex = 22;
            // 
            // txtAge
            // 
            this.txtAge.Location = new System.Drawing.Point(158, 66);
            this.txtAge.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.txtAge.Name = "txtAge";
            this.txtAge.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.txtAge.Size = new System.Drawing.Size(124, 27);
            this.txtAge.TabIndex = 21;
            this.txtAge.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // listBoxGenders
            // 
            this.listBoxGenders.FormattingEnabled = true;
            this.listBoxGenders.ItemHeight = 19;
            this.listBoxGenders.Location = new System.Drawing.Point(10, 108);
            this.listBoxGenders.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.listBoxGenders.Name = "listBoxGenders";
            this.listBoxGenders.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.listBoxGenders.Size = new System.Drawing.Size(124, 213);
            this.listBoxGenders.TabIndex = 24;
            // 
            // radioBtnFeminine
            // 
            this.radioBtnFeminine.AutoSize = true;
            this.radioBtnFeminine.Location = new System.Drawing.Point(45, 70);
            this.radioBtnFeminine.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.radioBtnFeminine.Name = "radioBtnFeminine";
            this.radioBtnFeminine.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.radioBtnFeminine.Size = new System.Drawing.Size(60, 23);
            this.radioBtnFeminine.TabIndex = 26;
            this.radioBtnFeminine.TabStop = true;
            this.radioBtnFeminine.Text = "أنثى";
            this.radioBtnFeminine.UseVisualStyleBackColor = true;
            // 
            // radioBtnMale
            // 
            this.radioBtnMale.AutoSize = true;
            this.radioBtnMale.Location = new System.Drawing.Point(52, 50);
            this.radioBtnMale.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.radioBtnMale.Name = "radioBtnMale";
            this.radioBtnMale.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.radioBtnMale.Size = new System.Drawing.Size(53, 23);
            this.radioBtnMale.TabIndex = 25;
            this.radioBtnMale.TabStop = true;
            this.radioBtnMale.Text = "ذكر";
            this.radioBtnMale.UseVisualStyleBackColor = true;
            // 
            // btnEdit
            // 
            this.btnEdit.BackColor = System.Drawing.Color.LightCyan;
            this.btnEdit.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnEdit.Location = new System.Drawing.Point(625, 289);
            this.btnEdit.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.btnEdit.Name = "btnEdit";
            this.btnEdit.Size = new System.Drawing.Size(94, 32);
            this.btnEdit.TabIndex = 30;
            this.btnEdit.Text = "تعديل";
            this.btnEdit.UseVisualStyleBackColor = false;
            this.btnEdit.Click += new System.EventHandler(this.btnEdit_Click);
            // 
            // btnDeletesAll
            // 
            this.btnDeletesAll.BackColor = System.Drawing.Color.LightCyan;
            this.btnDeletesAll.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnDeletesAll.Location = new System.Drawing.Point(625, 227);
            this.btnDeletesAll.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.btnDeletesAll.Name = "btnDeletesAll";
            this.btnDeletesAll.Size = new System.Drawing.Size(94, 32);
            this.btnDeletesAll.TabIndex = 29;
            this.btnDeletesAll.Text = "حذف الكل";
            this.btnDeletesAll.UseVisualStyleBackColor = false;
            this.btnDeletesAll.Click += new System.EventHandler(this.btnDeletesAll_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.BackColor = System.Drawing.Color.LightCyan;
            this.btnDelete.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnDelete.Location = new System.Drawing.Point(625, 166);
            this.btnDelete.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(94, 32);
            this.btnDelete.TabIndex = 28;
            this.btnDelete.Text = "حذف";
            this.btnDelete.UseVisualStyleBackColor = false;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnAdd
            // 
            this.btnAdd.BackColor = System.Drawing.Color.LightCyan;
            this.btnAdd.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnAdd.Location = new System.Drawing.Point(625, 108);
            this.btnAdd.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(94, 32);
            this.btnAdd.TabIndex = 27;
            this.btnAdd.Text = "اضافة";
            this.btnAdd.UseVisualStyleBackColor = false;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // btnClose
            // 
            this.btnClose.BackColor = System.Drawing.Color.Red;
            this.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnClose.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnClose.Location = new System.Drawing.Point(22, 333);
            this.btnClose.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(94, 32);
            this.btnClose.TabIndex = 31;
            this.btnClose.Text = "اغلاق";
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(728, 377);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.btnEdit);
            this.Controls.Add(this.btnDeletesAll);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.radioBtnFeminine);
            this.Controls.Add(this.radioBtnMale);
            this.Controls.Add(this.listBoxGenders);
            this.Controls.Add(this.listBoxAges);
            this.Controls.Add(this.txtAge);
            this.Controls.Add(this.listBoxNames);
            this.Controls.Add(this.txtName);
            this.Controls.Add(this.listBoxIds);
            this.Controls.Add(this.txtId);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(2, 4, 2, 4);
            this.Name = "Form2";
            this.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtId;
        private System.Windows.Forms.ListBox listBoxIds;
        private System.Windows.Forms.ListBox listBoxNames;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.ListBox listBoxAges;
        private System.Windows.Forms.TextBox txtAge;
        private System.Windows.Forms.ListBox listBoxGenders;
        private System.Windows.Forms.RadioButton radioBtnFeminine;
        private System.Windows.Forms.RadioButton radioBtnMale;
        private System.Windows.Forms.Button btnEdit;
        private System.Windows.Forms.Button btnDeletesAll;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Button btnClose;
    }
}