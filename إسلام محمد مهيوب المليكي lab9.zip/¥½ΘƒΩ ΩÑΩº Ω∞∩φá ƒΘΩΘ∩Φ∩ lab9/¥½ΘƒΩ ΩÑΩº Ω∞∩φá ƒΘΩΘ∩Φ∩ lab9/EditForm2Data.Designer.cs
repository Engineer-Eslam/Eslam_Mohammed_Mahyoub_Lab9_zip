﻿namespace إسلام_محمد_مهيوب_المليكي_lab9
{
    partial class EditForm2Data
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.radioBtnEditFeminine = new System.Windows.Forms.RadioButton();
            this.radioBtnEditMale = new System.Windows.Forms.RadioButton();
            this.txtEditAge = new System.Windows.Forms.TextBox();
            this.txtEditName = new System.Windows.Forms.TextBox();
            this.txtEditId = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btnSaveEdit = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // radioBtnEditFeminine
            // 
            this.radioBtnEditFeminine.AutoSize = true;
            this.radioBtnEditFeminine.Location = new System.Drawing.Point(24, 69);
            this.radioBtnEditFeminine.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.radioBtnEditFeminine.Name = "radioBtnEditFeminine";
            this.radioBtnEditFeminine.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.radioBtnEditFeminine.Size = new System.Drawing.Size(60, 23);
            this.radioBtnEditFeminine.TabIndex = 35;
            this.radioBtnEditFeminine.TabStop = true;
            this.radioBtnEditFeminine.Text = "انثى";
            this.radioBtnEditFeminine.UseVisualStyleBackColor = true;
            // 
            // radioBtnEditMale
            // 
            this.radioBtnEditMale.AutoSize = true;
            this.radioBtnEditMale.Location = new System.Drawing.Point(31, 49);
            this.radioBtnEditMale.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.radioBtnEditMale.Name = "radioBtnEditMale";
            this.radioBtnEditMale.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.radioBtnEditMale.Size = new System.Drawing.Size(53, 23);
            this.radioBtnEditMale.TabIndex = 34;
            this.radioBtnEditMale.TabStop = true;
            this.radioBtnEditMale.Text = "ذكر";
            this.radioBtnEditMale.UseVisualStyleBackColor = true;
            // 
            // txtEditAge
            // 
            this.txtEditAge.Location = new System.Drawing.Point(137, 65);
            this.txtEditAge.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.txtEditAge.Name = "txtEditAge";
            this.txtEditAge.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.txtEditAge.Size = new System.Drawing.Size(124, 27);
            this.txtEditAge.TabIndex = 33;
            this.txtEditAge.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtEditName
            // 
            this.txtEditName.Location = new System.Drawing.Point(288, 65);
            this.txtEditName.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.txtEditName.Name = "txtEditName";
            this.txtEditName.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.txtEditName.Size = new System.Drawing.Size(150, 27);
            this.txtEditName.TabIndex = 32;
            this.txtEditName.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtEditId
            // 
            this.txtEditId.Location = new System.Drawing.Point(465, 65);
            this.txtEditId.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.txtEditId.Name = "txtEditId";
            this.txtEditId.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.txtEditId.Size = new System.Drawing.Size(124, 27);
            this.txtEditId.TabIndex = 31;
            this.txtEditId.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(29, 21);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(59, 19);
            this.label4.TabIndex = 30;
            this.label4.Text = "الجنس";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(183, 21);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(46, 19);
            this.label3.TabIndex = 29;
            this.label3.Text = "العمر";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(344, 21);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(54, 19);
            this.label2.TabIndex = 28;
            this.label2.Text = "الاسم";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(507, 21);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(47, 19);
            this.label1.TabIndex = 27;
            this.label1.Text = "الرقم";
            // 
            // btnSaveEdit
            // 
            this.btnSaveEdit.BackColor = System.Drawing.Color.LightCyan;
            this.btnSaveEdit.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnSaveEdit.Location = new System.Drawing.Point(203, 111);
            this.btnSaveEdit.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.btnSaveEdit.Name = "btnSaveEdit";
            this.btnSaveEdit.Size = new System.Drawing.Size(195, 38);
            this.btnSaveEdit.TabIndex = 36;
            this.btnSaveEdit.Text = "حفظ";
            this.btnSaveEdit.UseVisualStyleBackColor = false;
            this.btnSaveEdit.Click += new System.EventHandler(this.btnSaveEdit_Click);
            // 
            // EditForm2Data
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(624, 173);
            this.Controls.Add(this.btnSaveEdit);
            this.Controls.Add(this.radioBtnEditFeminine);
            this.Controls.Add(this.radioBtnEditMale);
            this.Controls.Add(this.txtEditAge);
            this.Controls.Add(this.txtEditName);
            this.Controls.Add(this.txtEditId);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.Name = "EditForm2Data";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "EditForm2Data";
            this.Load += new System.EventHandler(this.EditForm2Data_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RadioButton radioBtnEditFeminine;
        private System.Windows.Forms.RadioButton radioBtnEditMale;
        private System.Windows.Forms.TextBox txtEditAge;
        private System.Windows.Forms.TextBox txtEditName;
        private System.Windows.Forms.TextBox txtEditId;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnSaveEdit;
    }
}